package com.isaac.imadpart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // declaring all variable
        // setting numbers entered to integers

        var edtNum1 = findViewById<EditText>(R.id.edtNum1)
        var edtNum2 = findViewById<EditText>(R.id.edtNum2)
        var btnAdd = findViewById<Button>(R.id.btnAdd)
        var btnSubtract = findViewById<Button>(R.id.btnSubtract)
        var btnMultiply = findViewById<Button>(R.id.btnMultiply)
        var btnDivide = findViewById<Button>(R.id.btnDivide)
        var tvDisplay = findViewById<TextView>(R.id.tvDisplay)
        var btnClear = findViewById<Button>(R.id.btnClear)
        var btnSquareRoot = findViewById<Button>(R.id.btnSquareRoot)
        var btnPower = findViewById<Button>(R.id.btnPower)


        // adding functionality to the "Add" Button
        btnAdd.setOnClickListener {
            val res1 = edtNum1.text.toString().toInt()
            val res2 = edtNum2.text.toString().toInt()
            val result = res1 + res2
            tvDisplay.text = "$edtNum1 + $edtNum2 = $result"
        }
        // adding functionality to the "Subtract" Button
        btnSubtract.setOnClickListener {
            val res1 = edtNum1.text.toString().toInt()
            val res2 = edtNum2.text.toString().toInt()
            val result = res1 - res2
            tvDisplay.text = "$edtNum1 - $edtNum2 = $result"
        }
        // adding functionality to the "Multiply" Button
        btnMultiply.setOnClickListener {
            val res1 = edtNum1.text.toString().toInt()
            val res2 = edtNum2.text.toString().toInt()
            val result = res1 * res2
            tvDisplay.text = "$edtNum1 * $edtNum2 = $result"
        }
        // adding functionality to the "Divide" Button
        btnDivide.setOnClickListener {
            val res1 = edtNum1.text.toString().toInt()
            val res2 = edtNum2.text.toString().toInt()
            val result = res1 / res2
            tvDisplay.text = "$edtNum1 / $edtNum2 = $result"
            val edtNum2 = 0
            if (edtNum2 < 0) {
                println("Error! You cannot divide by 0")
            }
        }
        // button to clear the entered numbers in the edit boxes
        btnClear.setOnClickListener {
            edtNum1.setText("");
            edtNum2.setText("");
        }
        btnSquareRoot.setOnClickListener {
            val res1 = edtNum1.text.toString().toInt()
            val res2 = edtNum2.text.toString().toInt()
            val result = res1 * res1 / 2
            tvDisplay.text = "$edtNum1 * $edtNum1 / 2 = $result"
            if (edtNum2 < 0)
                tvDisplay.text = "$edtNum1 = $result i"
        }

       fun main(args: Array<String>){
           val base = 2
           var exponent = 3
           var result: Long = 1

           while (exponent != 0 ){
               result *= base.toLong()
               --exponent
           }
           btnPower.setOnClickListener {
               val res1 = edtNum1.text.toString().toInt()
               val res2 = edtNum2.text.toString().toInt()

           }
           tvDisplay.text = "$edtNum1 to the power of $edtNum2 = $result"
       }
        val buttonClick = findViewById<Button>(R.id.button_click)
        buttonClick.setOnClickListener {
            val intent = Intent(this, activity_main2.xml::class.java)
            startActivity(intent)
        }

    }
}