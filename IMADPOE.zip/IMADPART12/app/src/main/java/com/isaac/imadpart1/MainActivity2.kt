package com.isaac.imadpart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Example1">
        <activity
        android:name=".MainActivity"
        android:exported="true">
        <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
        </activity>
        <activity android:name="activity_main2.xml"></activity>
        </application>


        //declaring all variables

        var tvEnterNumber = findViewById<TextView>(R.id.tvEnterNumber)
        var edtEnter = findViewById<EditText>(R.id.edtEnter)
        var btnAdded = findViewById<Button>(R.id.btnAdded)
        var tvMemory = findViewById<TextView>(R.id.tvMemory)
        var tvStored = findViewById<TextView>(R.id.tvStored)
        var btnCleared = findViewById<Button>(R.id.btnCleared)
        var btnCalc = findViewById<Button>(R.id.btnCalc)
        var btnMinMax = findViewById<Button>(R.id.btnMinMax)
        var tvFinal = findViewById<TextView>(R.id.tvFinal)

        //creating array

        var array = arrayOf(edtEnter)
        println(array.joinToString())
        tvMemory.text = "$array"

        //creating somewhere for the information to be stored
        btnAdded.setOnClickListener {
            tvMemory.text = "$edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter, $edtEnter"
            if (tvMemory > 10)
                print("Too many numbers entered! Maximum amount of numbers is 10.")
        }
        btnCleared.setOnClickListener {
            tvMemory.setText("");
    }
        //calculating average
        btnCalc.setOnClickListener {
            fun main(args: Array<String>) {
                val numArray = doubleArrayOf(65.2, 67.5, 4.6, 99.9, 21.0, 23.0)
                var sum = 0.0

                for (num in numArray) {
                    sum += num
                }

                val average = sum / numArray.size
                tvFinal.text = ("The average is: %.2f".format(average))
            }
        }
        //finding Minimum and Maximum
        btnMinMax.setOnClickListener {
            fun getMin(arrX: Array<Int>): Int {
                var min = Int.MAX_VALUE
                for (i in arrX) {
                    min =  min.coerceAtMost(i)
                }
                return min
            }

            fun getMax(arrX: Array<Int>): Int {
                var max = Int.MIN_VALUE
                for (i in arrX) {
                    max = max.coerceAtLeast(i)
                }
                return max
            }

            tvFinal.text = "The Min is "+ getMin(array)  + " and the Max is " + getMax(array)

        }
        }
}